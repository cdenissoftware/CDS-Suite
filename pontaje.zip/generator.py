from datetime import datetime
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from reportlab.lib.pagesizes import landscape, A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import calendar
import os

LUNI_RO = {
    1: "IANUARIE",
    2: "FEBRUARIE",
    3: "MARTIE",
    4: "APRILIE",
    5: "MAI",
    6: "IUNIE",
    7: "IULIE",
    8: "AUGUST",
    9: "SEPTEMBRIE",
    10: "OCTOMBRIE",
    11: "NOIEMBRIE",
    12: "DECEMBRIE"
}

WEEKEND_FILL = PatternFill(start_color="FFD966", end_color="FFD966", fill_type="solid")


def set_cell_value(ws, cell_ref, value):
    for merged in ws.merged_cells.ranges:
        if cell_ref in merged:
            master = merged.start_cell
            ws[master.coordinate].value = value
            return
    ws[cell_ref].value = value


LAYOUT_STANDARD = {
    "an_cell": "AA11",
    "luna_cell": "O11",
    "primul_rand": 17,
    "col_nume": "C",
    "col_functie": "D",

    "zile": {
        1: "F", 2: "G", 3: "H", 4: "I", 5: "J", 6: "K", 7: "L",
        8: "M", 9: "N", 10: "O", 11: "P", 12: "Q", 13: "R", 14: "S",
        15: "T", 16: "V", 17: "W", 18: "X", 19: "Y", 20: "Z",
        21: "AA", 22: "AB", 23: "AC", 24: "AD", 25: "AE",
        26: "AF", 27: "AG", 28: "AH", 29: "AI", 30: "AJ", 31: "AK"
    }
}


class PontajGenerator:
    def __init__(self, baza_templateuri: str, baza_output: str):
        self.baza_templateuri = baza_templateuri
        self.baza_output = baza_output
        os.makedirs(self.baza_output, exist_ok=True)

    def _path_template(self, tip):
        return os.path.join(self.baza_templateuri, f"{tip}.xlsx")

    def _path_output(self, tip: str, luna: int, an: int):
        folder_an = os.path.join(self.baza_output, str(an))
        folder_luna = os.path.join(folder_an, f"{luna:02d}")
        os.makedirs(folder_luna, exist_ok=True)

        base = f"pontaj_{tip.lower()}_{an}_{luna:02d}"
        ext = ".xlsx"
        path = os.path.join(folder_luna, base + ext)

        counter = 1
        while os.path.exists(path):
            path = os.path.join(folder_luna, f"{base}_#{counter}{ext}")
            counter += 1

        return path

    # 🔥 GENERARE PDF PROFESIONAL CU DIACRITICE
    def genereaza_pdf(self, path_excel, luna, an, angajati, zile_luna):
        pdf_path = path_excel.replace(".xlsx", ".pdf")

        # 🔥 Calea corectă către font (în folderul aplicației)
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        font_path = os.path.join(BASE_DIR, "fonts", "DejaVuSans.ttf")

        if not os.path.exists(font_path):
            raise FileNotFoundError(f"Fontul nu există: {font_path}")

        pdfmetrics.registerFont(TTFont("DejaVu", font_path))

        c = canvas.Canvas(pdf_path, pagesize=landscape(A4))
        c.setFont("DejaVu", 16)

        # Titlu
        c.drawString(30, 560, f"FOAIE COLECTIVĂ DE PREZENȚĂ - {LUNI_RO[luna]} {an}")

        # Construim antetul tabelului
        header = ["Nr", "Nume", "Funcție"] + [str(i) for i in range(1, zile_luna + 1)]
        data = [header]

        nr = 1
        for ang in angajati:
            row = [nr, ang["nume"], ang["functie"]]
            for zi in range(1, zile_luna + 1):
                val = ang["ore"].get(str(zi), "")
                if val == "":
                    data_zi = datetime(an, luna, zi)
                    if data_zi.weekday() >= 5:
                        row.append("")  # weekend gol
                    else:
                        row.append("8")
                else:
                    row.append(val)
            data.append(row)
            nr += 1

        # Lățimi coloane
        col_widths = [25, 120, 90] + [20] * zile_luna

        # Creăm tabelul PDF
        table = Table(data, colWidths=col_widths)

        # Stil profesional
        style = TableStyle([
            ("FONT", (0, 0), (-1, -1), "DejaVu", 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LINEBELOW", (0, 0), (-1, 0), 1.2, colors.black),
        ])

        table.setStyle(style)

        table.wrapOn(c, 30, 200)
        table.drawOn(c, 30, 340)

        c.save()
        return pdf_path

    def genereaza(self, tip: str, luna: int, an: int, angajati: list):
        layout = LAYOUT_STANDARD

        template_path = self._path_template(tip)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Nu există template pentru tipul '{tip}': {template_path}")

        wb = load_workbook(template_path)
        ws = wb.active

        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_setup.orientation = "landscape"

        set_cell_value(ws, layout["an_cell"], f"Anul {an}")
        set_cell_value(ws, layout["luna_cell"], LUNI_RO[luna])

        zile_luna = calendar.monthrange(an, luna)[1]
        rand = layout["primul_rand"]

        # 🔥 ȘTERGEM TEXTUL 29, 30, 31 DIN ANTET
        for zi in range(zile_luna + 1, 32):
            col = layout["zile"][zi]
            ws[f"{col}16"].value = ""

        for ang in angajati:
            set_cell_value(ws, f"{layout['col_nume']}{rand}", ang["nume"])
            set_cell_value(ws, f"{layout['col_functie']}{rand}", ang["functie"])

            # Ștergem celulele angajaților pentru zile inexistente
            for zi in range(zile_luna + 1, 32):
                col = layout["zile"][zi]
                ws[f"{col}{rand}"].value = ""
                ws[f"{col}{rand}"].fill = PatternFill(fill_type=None)

            # Completăm zilele existente
            for zi in range(1, zile_luna + 1):
                col = layout["zile"][zi]
                cell_ref = f"{col}{rand}"

                val = ang["ore"].get(str(zi), "")

                if val == "":
                    data_zi = datetime(an, luna, zi)
                    if data_zi.weekday() >= 5:
                        ws[cell_ref].value = ""
                        ws[cell_ref].fill = WEEKEND_FILL
                    else:
                        set_cell_value(ws, cell_ref, 8)
                else:
                    set_cell_value(ws, cell_ref, val)

            rand += 1

        out_excel = self._path_output(tip, luna, an)
        wb.save(out_excel)

        # 🔥 GENERĂM PDF PROFESIONAL
        self.genereaza_pdf(out_excel, luna, an, angajati, zile_luna)

        return out_excel
