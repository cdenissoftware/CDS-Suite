import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

def path_tip(tip):
    return os.path.join(DATA_DIR, f"{tip}.json")


# ---------------------------------------------------------
# STRUCTURA COMPLETĂ (2020–2035)
# ---------------------------------------------------------
def structura_goala():
    return {
        str(an): {
            str(luna): {str(zi): "" for zi in range(1, 32)}
            for luna in range(1, 13)
        }
        for an in range(2020, 2036)
    }


# ---------------------------------------------------------
# REPARĂ STRUCTURA ANGAJAȚILOR EXISTENȚI
# ---------------------------------------------------------
def repara_structura(lista):
    for ang in lista:

        # dacă nu are pontaj deloc → îl creăm complet
        if "pontaj" not in ang:
            ang["pontaj"] = structura_goala()
            continue

        # completăm anii lipsă
        for an in range(2020, 2036):
            an = str(an)
            if an not in ang["pontaj"]:
                ang["pontaj"][an] = {str(l): {str(z): "" for z in range(1, 32)} for l in range(1, 13)}

            # completăm lunile lipsă
            for luna in range(1, 13):
                luna = str(luna)
                if luna not in ang["pontaj"][an]:
                    ang["pontaj"][an][luna] = {str(z): "" for z in range(1, 32)}

                # completăm zilele lipsă
                for zi in range(1, 32):
                    zi = str(zi)
                    if zi not in ang["pontaj"][an][luna]:
                        ang["pontaj"][an][luna][zi] = ""

    return lista


# ---------------------------------------------------------
# ÎNCARCĂ ANGAJAȚII + REPARĂ STRUCTURA AUTOMAT
# ---------------------------------------------------------
def incarca_angajati(tip):
    path = path_tip(tip)
    if not os.path.exists(path):
        return []

    with open(path, "r", encoding="utf-8") as f:
        lista = json.load(f)

    # reparăm structura dacă lipsesc ani/luni/zile
    lista = repara_structura(lista)

    # salvăm înapoi structura reparată
    salveaza_angajati(tip, lista)

    return lista


# ---------------------------------------------------------
# SALVEAZĂ ANGAJAȚII
# ---------------------------------------------------------
def salveaza_angajati(tip, lista):
    path = path_tip(tip)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(lista, f, indent=4, ensure_ascii=False)
