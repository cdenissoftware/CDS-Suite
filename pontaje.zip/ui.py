import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from tkcalendar import Calendar
import calendar
from datetime import datetime
import os

from .data_manager import incarca_angajati, salveaza_angajati, structura_goala
from .generator import PontajGenerator


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

def lista_tipuri_pontaj():
    tipuri = []
    if os.path.exists(TEMPLATES_DIR):
        for f in os.listdir(TEMPLATES_DIR):
            if f.lower().endswith(".xlsx"):
                tipuri.append(os.path.splitext(f)[0])  # numele fără .xlsx
    return tipuri

os.makedirs(OUTPUT_DIR, exist_ok=True)

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

luni_nume = [
    "Ianuarie", "Februarie", "Martie", "Aprilie",
    "Mai", "Iunie", "Iulie", "August",
    "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
]


# ---------------------------------------------------------
# FEREASTRĂ: TABEL PONTAJ
# ---------------------------------------------------------
def deschide_tabel_pontaj():
    import tkinter.ttk as ttk

    style = ttk.Style()
    style.theme_use("default")

    style.configure(
        "Horizontal.TScrollbar",
        troughcolor="#D0D0D0",
        background="#1E88E5",
        darkcolor="#1E88E5",
        lightcolor="#1E88E5",
        bordercolor="#1E88E5",
        arrowcolor="white",
        gripcount=0,
        thickness=18
    )

    style.configure(
        "Vertical.TScrollbar",
        troughcolor="#D0D0D0",
        background="#1E88E5",
        darkcolor="#1E88E5",
        lightcolor="#1E88E5",
        bordercolor="#1E88E5",
        arrowcolor="white",
        gripcount=0,
        thickness=18
    )

    tip = tip_var.get()
    lista = incarca_angajati(tip)

    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip de pontaj.")
        return

    # luna din combobox (cu nume) → număr
    luni_nume = [
        "Ianuarie", "Februarie", "Martie", "Aprilie",
        "Mai", "Iunie", "Iulie", "August",
        "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ]
    luna = luni_nume.index(luna_var.get()) + 1
    an = int(an_var.get())
    zile_luna = calendar.monthrange(an, luna)[1]

    top = ctk.CTkToplevel()
    top.title(f"Tabel Pontaj - {luna}/{an}")
    top.geometry("1300x700")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(100, lambda: top.attributes("-topmost", False))

    container = tk.Frame(top)
    container.pack(fill="both", expand=True)

    canvas = tk.Canvas(container, bg="#F0F0F0")
    canvas.pack(side="left", fill="both", expand=True)

    scrollbar_y = ttk.Scrollbar(container, orient="vertical", command=canvas.yview, style="Vertical.TScrollbar")
    scrollbar_y.pack(side="right", fill="y")

    scrollbar_x = ttk.Scrollbar(top, orient="horizontal", command=canvas.xview, style="Horizontal.TScrollbar")
    scrollbar_x.pack(side="bottom", fill="x")

    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)

    frame_table = tk.Frame(canvas, bg="#F0F0F0")
    canvas.create_window((0, 0), window=frame_table, anchor="nw")

    header_bg = "#1E88E5"
    header_fg = "white"

    headers = ["Nume", "Funcție"] + [str(i) for i in range(1, zile_luna + 1)] + ["Total"]

    for col, h in enumerate(headers):
        lbl = tk.Label(
            frame_table,
            text=h,
            font=("Arial", 12, "bold"),
            bg=header_bg,
            fg=header_fg,
            borderwidth=1,
            relief="solid",
            width=6
        )
        lbl.grid(row=0, column=col, sticky="nsew")

    VALID_MARKS = ["", "8", "L", "Co", "Bo", "Bp", "M", "O", "N", "Prm", "Prb"]

    def valideaza_celula(event, entry, zi):
        val = entry.get().strip()
        if val not in VALID_MARKS:
            entry.configure(bg="#FFCCCC")
        else:
            d = datetime(an, luna, zi)
            if d.weekday() >= 5:
                entry.configure(bg="#FFE9A8")
            else:
                entry.configure(bg="white")

    entries = []

    an_key = str(an)
    luna_key = str(luna)

    for r, ang in enumerate(lista, start=1):
        row_entries = []
        row_bg = "#FFFFFF" if r % 2 == 1 else "#F5F5F5"

        e_nume = tk.Entry(frame_table, width=18, bg=row_bg, font=("Arial", 12))
        e_nume.insert(0, ang["nume"])
        e_nume.grid(row=r, column=0, sticky="nsew")
        row_entries.append(e_nume)

        e_fct = tk.Entry(frame_table, width=18, bg=row_bg, font=("Arial", 12))
        e_fct.insert(0, ang["functie"])
        e_fct.grid(row=r, column=1, sticky="nsew")
        row_entries.append(e_fct)

        total_ore = 0

        # ne asigurăm că există structura pentru anul/luna curentă
        if "pontaj" not in ang:
            ang["pontaj"] = {}
        if an_key not in ang["pontaj"]:
            ang["pontaj"][an_key] = {}
        if luna_key not in ang["pontaj"][an_key]:
            ang["pontaj"][an_key][luna_key] = {str(i): "" for i in range(1, 32)}

        for zi in range(1, zile_luna + 1):
            val = ang["pontaj"][an_key][luna_key].get(str(zi), "")

            if val == "":
                d = datetime(an, luna, zi)
                if d.weekday() < 5:
                    val = "8"
                    total_ore += 8
            else:
                try:
                    total_ore += int(val)
                except:
                    pass

            d = datetime(an, luna, zi)
            bg = "#FFE9A8" if d.weekday() >= 5 else row_bg

            e = tk.Entry(frame_table, width=4, bg=bg, font=("Arial", 12))
            e.insert(0, val)
            e.grid(row=r, column=zi + 1, sticky="nsew")
            e.bind("<KeyRelease>", lambda ev, ent=e, z=zi: valideaza_celula(ev, ent, z))

            row_entries.append(e)

        e_total = tk.Entry(frame_table, width=6, bg="#D0E8FF", font=("Arial", 12, "bold"))
        e_total.insert(0, str(total_ore))
        e_total.grid(row=r, column=zile_luna + 2, sticky="nsew")
        row_entries.append(e_total)

        entries.append(row_entries)

    def salveaza_modificari():
        for r, row in enumerate(entries):
            ang = lista[r]

            nume = row[0].get().strip()
            functie = row[1].get().strip()
            ang["nume"] = nume
            ang["functie"] = functie

            if "pontaj" not in ang:
                ang["pontaj"] = {}
            if an_key not in ang["pontaj"]:
                ang["pontaj"][an_key] = {}
            if luna_key not in ang["pontaj"][an_key]:
                ang["pontaj"][an_key][luna_key] = {str(i): "" for i in range(1, 32)}

            for zi in range(1, zile_luna + 1):
                ang["pontaj"][an_key][luna_key][str(zi)] = row[zi + 1].get().strip()

        salveaza_angajati(tip, lista)
        messagebox.showinfo("Succes", "Modificările au fost salvate.")

    ctk.CTkButton(top, text="Salvează modificările",
                  fg_color="#007ACC", height=40,
                  command=salveaza_modificari).pack(pady=10)

    def reseteaza_luna():
        if not messagebox.askyesno("Confirmare", "Sigur vrei să resetezi toate marcajele?"):
            return

        for ang in lista:
            if "pontaj" not in ang:
                ang["pontaj"] = {}
            if an_key not in ang["pontaj"]:
                ang["pontaj"][an_key] = {}
            ang["pontaj"][an_key][luna_key] = {str(i): "" for i in range(1, 32)}

        salveaza_angajati(tip, lista)
        messagebox.showinfo("Succes", "Luna a fost resetată.")
        top.destroy()
        deschide_tabel_pontaj()

    ctk.CTkButton(top, text="Resetează luna",
                  fg_color="#AA0000", height=35,
                  command=reseteaza_luna).pack(pady=5)

    frame_table.update_idletasks()
    canvas.config(scrollregion=canvas.bbox("all"))

# ---------------------------------------------------------
# FEREASTRĂ: MARCAJE SPECIALE (calendar permanent)
# ---------------------------------------------------------
# ---------------------------------------------------------
# FEREASTRĂ: MARCAJE SPECIALE (calendar permanent)
# ---------------------------------------------------------
def fereastra_marcaje_speciale():
    tip = tip_var.get()
    lista = incarca_angajati(tip)

    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip.")
        return

    # anul și luna curentă
    an = str(datetime.now().year)
    luna = str(datetime.now().month)

    top = ctk.CTkToplevel()
    top.title("Marcaje speciale")
    top.geometry("480x520")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(200, lambda: top.attributes("-topmost", False))

    # ------------------------------
    # COL STÂNGA
    # ------------------------------
    left = ctk.CTkFrame(top, corner_radius=15)
    left.grid(row=0, column=0, sticky="n", padx=8, pady=8)

    ctk.CTkLabel(left, text="Alege angajatul", font=ctk.CTkFont(size=15, weight="bold")).pack(pady=10)

    nume_lista = [f"{a['nume']} - {a['functie']}" for a in lista]
    angajat_var = ctk.StringVar(value=nume_lista[0])

    def schimbare(_=None):
        coloreaza()

    combo_ang = ctk.CTkComboBox(
        left,
        values=nume_lista,
        variable=angajat_var,
        width=240,
        command=schimbare
    )
    combo_ang.pack(pady=5)

    ctk.CTkLabel(left, text="Tip marcaj", font=ctk.CTkFont(size=15)).pack(pady=10)

    marcaje = ["Șterge marcajul", "L", "Co", "Bo", "Bp", "M", "O", "N", "Prm", "Prb"]
    marcaj_var = ctk.StringVar(value="L")

    combo_mark = ctk.CTkComboBox(left, values=marcaje, variable=marcaj_var, width=200)
    combo_mark.pack(pady=5)

    # ------------------------------
    # BUTON ȘTERGE TOATE MARCAJELE
    # ------------------------------
    def sterge_toate():
        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]

        for zi in range(1, 32):
            ang["pontaj"][an][luna][str(zi)] = ""

        salveaza_angajati(tip, lista)
        coloreaza()
        messagebox.showinfo("Succes", "Toate marcajele au fost șterse.")

    ctk.CTkButton(left, text="Șterge toate marcajele", fg_color="#D32F2F", height=40, command=sterge_toate).pack(pady=20)

    # ------------------------------
    # COL DREAPTA – CALENDAR
    # ------------------------------
    right = ctk.CTkFrame(top, corner_radius=15)
    right.grid(row=0, column=1, sticky="n", padx=8, pady=8)

    ctk.CTkLabel(right, text="Selectează o zi", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)

    now = datetime.now()

    cal = Calendar(
        right,
        selectmode="day",
        year=now.year,
        month=now.month,
        day=1,
        date_pattern="dd/mm/yyyy"
    )
    cal.pack(pady=10)

    culori = {
        "L": "#FFF59D",
        "Co": "#90CAF9",
        "Bo": "#EF9A9A",
        "Bp": "#FFCC80",
        "M": "#CE93D8",
        "O": "#BDBDBD",
        "N": "#B39DDB",
        "Prm": "#A5D6A7",
        "Prb": "#A5D6A7"
    }

    # ------------------------------
    # FUNCȚIE: colorează calendarul
    # ------------------------------
    def coloreaza():
        for ev in cal.get_calevents():
            cal.calevent_remove(ev)

        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]

        for zi in range(1, 32):
            marc = ang["pontaj"][an][luna].get(str(zi), "")
            if marc in culori:
                try:
                    cal.calevent_create(
                        datetime(now.year, now.month, zi),
                        "",
                        marc
                    )
                    cal.tag_config(marc, background=culori[marc])
                except:
                    pass

    coloreaza()

    # ------------------------------
    # SELECTARE ZI
    # ------------------------------
    def select_zi(event):
        zi = cal.get_date().split("/")[0].lstrip("0")
        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]

        marc = ang["pontaj"][an][luna].get(zi, "")
        marcaj_var.set(marc if marc else marcaj_var.get())

    cal.bind("<<CalendarSelected>>", select_zi)

    # ------------------------------
    # APLICĂ MARCAJ
    # ------------------------------
    def aplica():
        zi = cal.get_date().split("/")[0].lstrip("0")
        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]

        marc = marcaj_var.get()
        ang["pontaj"][an][luna][zi] = "" if marc == "Șterge marcajul" else marc

        salveaza_angajati(tip, lista)
        coloreaza()

       # messagebox.showinfo("Succes", f"Marcaj aplicat pentru ziua {zi}.")

    ctk.CTkButton(right, text="Aplică marcaj", fg_color="#007ACC", height=40, command=aplica).pack(pady=10)

    # ------------------------------
    # LEGENDA COLORATĂ – 3 COLOANE
    # ------------------------------
    legenda = ctk.CTkFrame(top, corner_radius=10)
    legenda.grid(row=1, column=0, columnspan=2, pady=5)

    ctk.CTkLabel(
        legenda,
        text="Legendă marcaje",
        font=ctk.CTkFont(size=14, weight="bold")
    ).grid(row=0, column=0, columnspan=3, pady=5)

    items = list(culori.items())
    col_size = (len(items) + 2) // 3

    col1 = items[0:col_size]
    col2 = items[col_size:col_size*2]
    col3 = items[col_size*2:]

    coloane = [col1, col2, col3]

    for col_index, col_data in enumerate(coloane):
        for row_index, (cod, culoare) in enumerate(col_data, start=1):
            frame = ctk.CTkFrame(legenda)
            frame.grid(row=row_index, column=col_index, sticky="w", padx=5, pady=1)

            ctk.CTkLabel(frame, text="   ", width=20, fg_color=culoare).pack(side="left", padx=5)
            ctk.CTkLabel(frame, text=cod, font=ctk.CTkFont(size=13)).pack(side="left")

# ---------------------------------------------------------
# FEREASTRĂ: ADAUGĂ ANGAJAT
# ---------------------------------------------------------
def adauga_angajat():
    top = ctk.CTkToplevel()
    top.title("Adaugă angajat")
    top.geometry("420x360")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(100, lambda: top.attributes("-topmost", False))

    ctk.CTkLabel(
        top,
        text="Adaugă angajat",
        font=ctk.CTkFont(size=22, weight="bold")
    ).pack(pady=20)

    card = ctk.CTkFrame(top, corner_radius=15)
    card.pack(fill="x", padx=20, pady=10)

    ctk.CTkLabel(card, text="Nume angajat:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    nume_var = ctk.StringVar()
    ctk.CTkEntry(card, textvariable=nume_var, width=300, font=ctk.CTkFont(size=14)).pack(pady=5)

    ctk.CTkLabel(card, text="Funcție:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    functie_var = ctk.StringVar()
    ctk.CTkEntry(card, textvariable=functie_var, width=300, font=ctk.CTkFont(size=14)).pack(pady=5)

    def salveaza():
        nume = nume_var.get().strip()
        functie = functie_var.get().strip()
        tip = tip_var.get()

        if not nume or not functie:
            messagebox.showwarning("Atenție", "Completează toate câmpurile.")
            return

        lista = incarca_angajati(tip)
        lista.append({
            "nume": nume,
            "functie": functie,
            "pontaj": structura_goala()
        })

        salveaza_angajati(tip, lista)
        messagebox.showinfo("Succes", "Angajat adăugat cu succes.")
        top.destroy()

    ctk.CTkButton(
        top,
        text="Salvează angajatul",
        fg_color="#1E88E5",
        height=45,
        font=ctk.CTkFont(size=15, weight="bold"),
        command=salveaza
    ).pack(pady=25)

# ---------------------------------------------------------
# FEREASTRĂ: ȘTERGE ANGAJAT
# ---------------------------------------------------------
def sterge_angajat():
    tip = tip_var.get()
    lista = incarca_angajati(tip)

    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip.")
        return

    top = ctk.CTkToplevel()
    top.title("Șterge angajat")
    top.geometry("420x300")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(100, lambda: top.attributes("-topmost", False))

    ctk.CTkLabel(top, text="Șterge angajat", font=ctk.CTkFont(size=22, weight="bold")).pack(pady=20)

    card = ctk.CTkFrame(top, corner_radius=15)
    card.pack(fill="x", padx=20, pady=10)

    nume_lista = [f"{ang['nume']} - {ang['functie']}" for ang in lista]
    angajat_var = ctk.StringVar(value=nume_lista[0])

    ctk.CTkLabel(card, text="Selectează angajatul:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    ctk.CTkComboBox(card, values=nume_lista, variable=angajat_var, width=300).pack(pady=5)

    def sterge():
        idx = nume_lista.index(angajat_var.get())
        lista.pop(idx)
        salveaza_angajati(tip, lista)
        messagebox.showinfo("Succes", "Angajat șters.")
        top.destroy()

    ctk.CTkButton(
        top,
        text="Șterge angajatul",
        fg_color="#D32F2F",
        height=45,
        font=ctk.CTkFont(size=15, weight="bold"),
        command=sterge
    ).pack(pady=20)


# ---------------------------------------------------------
# FEREASTRĂ: MODIFICĂ ANGAJAT
# ---------------------------------------------------------
def modifica_angajat():
    tip = tip_var.get()
    lista = incarca_angajati(tip)

    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip.")
        return

    top = ctk.CTkToplevel()
    top.title("Modifică angajat")
    top.geometry("420x420")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(100, lambda: top.attributes("-topmost", False))

    ctk.CTkLabel(top, text="Modifică angajat", font=ctk.CTkFont(size=22, weight="bold")).pack(pady=20)

    card = ctk.CTkFrame(top, corner_radius=15)
    card.pack(fill="x", padx=20, pady=10)

    nume_lista = [f"{ang['nume']} - {ang['functie']}" for ang in lista]
    angajat_var = ctk.StringVar(value=nume_lista[0])

    ctk.CTkLabel(card, text="Selectează angajatul:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    ctk.CTkComboBox(card, values=nume_lista, variable=angajat_var, width=300).pack(pady=5)

    ctk.CTkLabel(card, text="Nume nou:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    nume_var = ctk.StringVar()
    ctk.CTkEntry(card, textvariable=nume_var, width=300).pack(pady=5)

    ctk.CTkLabel(card, text="Funcție nouă:", font=ctk.CTkFont(size=14)).pack(pady=(15, 5))
    functie_var = ctk.StringVar()
    ctk.CTkEntry(card, textvariable=functie_var, width=300).pack(pady=5)

    def salveaza():
        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]

        if nume_var.get().strip():
            ang["nume"] = nume_var.get().strip()

        if functie_var.get().strip():
            ang["functie"] = functie_var.get().strip()

        salveaza_angajati(tip, lista)
        messagebox.showinfo("Succes", "Datele au fost actualizate.")
        top.destroy()

    ctk.CTkButton(
        top,
        text="Salvează modificările",
        fg_color="#0288D1",
        height=45,
        font=ctk.CTkFont(size=15, weight="bold"),
        command=salveaza
    ).pack(pady=20)


# ---------------------------------------------------------
# GENERARE PONTAJ
# ---------------------------------------------------------
def genereaza_pontaj():
    tip = tip_var.get()

    luni_nume = [
        "Ianuarie", "Februarie", "Martie", "Aprilie",
        "Mai", "Iunie", "Iulie", "August",
        "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ]
    luna_num = luni_nume.index(luna_var.get()) + 1
    an = int(an_var.get())

    lista = incarca_angajati(tip)
    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip.")
        return

    # pregătim câmpul "ore" pentru generator
    for ang in lista:
        if "pontaj" not in ang:
            ang["pontaj"] = {}
        if str(an) not in ang["pontaj"]:
            ang["pontaj"][str(an)] = {}
        if str(luna_num) not in ang["pontaj"][str(an)]:
            ang["pontaj"][str(an)][str(luna_num)] = {str(i): "" for i in range(1, 32)}

        ang["ore"] = ang["pontaj"][str(an)][str(luna_num)]

    gen = PontajGenerator(TEMPLATES_DIR, OUTPUT_DIR)
    out = gen.genereaza(tip, luna_num, an, lista)

    # -----------------------------
    # Mesaj + opțiuni suplimentare
    # -----------------------------
    rasp = messagebox.askyesno("Pontaj generat", "Pontajul a fost generat cu succes.\n\nVrei să îl listezi?")
    if rasp:
        try:
            os.startfile(out, "print")
        except:
            messagebox.showwarning("Eroare", "Nu s-a putut deschide previzualizarea pentru listare.")

    rasp2 = messagebox.askyesno("Deschidere folder", "Vrei să deschizi folderul cu pontajul generat?")
    if rasp2:
        folder = os.path.dirname(out)
        os.startfile(folder)


def statistici_angajat():
    tip = tip_var.get()
    lista = incarca_angajati(tip)

    if not lista:
        messagebox.showwarning("Atenție", "Nu există angajați pentru acest tip.")
        return

    top = ctk.CTkToplevel()
    top.title("Statistici angajat")
    top.geometry("500x600")
    top.lift()
    top.focus_force()
    top.attributes("-topmost", True)
    top.after(100, lambda: top.attributes("-topmost", False))

    ctk.CTkLabel(top, text="Statistici angajat", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=15)

    card = ctk.CTkFrame(top, corner_radius=15)
    card.pack(fill="x", padx=20, pady=10)

    nume_lista = [f"{ang['nume']} - {ang['functie']}" for ang in lista]
    angajat_var = ctk.StringVar(value=nume_lista[0])

    ctk.CTkLabel(card, text="Alege angajatul:", font=ctk.CTkFont(size=14)).pack(pady=(10, 5))
    ctk.CTkComboBox(card, values=nume_lista, variable=angajat_var, width=300).pack(pady=5)

    an_var_local = ctk.StringVar(value=str(datetime.now().year))
    ctk.CTkLabel(card, text="Alege anul:", font=ctk.CTkFont(size=14)).pack(pady=(10, 5))
    ctk.CTkComboBox(card, values=[str(i) for i in range(2020, 2036)], variable=an_var_local, width=300).pack(pady=5)

    rezultat = ctk.CTkTextbox(top, width=380, height=250, font=ctk.CTkFont(size=14))
    rezultat.pack(pady=10)

    def calculeaza():
        idx = nume_lista.index(angajat_var.get())
        ang = lista[idx]
        an = an_var_local.get()

        if "pontaj" not in ang or an not in ang["pontaj"]:
            messagebox.showinfo("Info", "Nu există pontaj pentru anul selectat.")
            rezultat.delete("1.0", "end")
            rezultat.insert("end", f"Nu există date pentru {ang['nume']} în {an}.\n")
            return

        total = {
            "L": 0, "Co": 0, "Bo": 0, "Bp": 0,
            "M": 0, "O": 0, "N": 0, "Prm": 0, "Prb": 0
        }

        for luna in range(1, 13):
            luna_key = str(luna)
            if luna_key not in ang["pontaj"][an]:
                continue
            zile = calendar.monthrange(int(an), luna)[1]
            for zi in range(1, zile + 1):
                marc = ang["pontaj"][an][luna_key].get(str(zi), "")
                if marc in total:
                    total[marc] += 1

        rezultat.delete("1.0", "end")
        rezultat.insert("end", f"Statistici pentru {ang['nume']} în anul {an}\n\n")
        for k, v in total.items():
            rezultat.insert("end", f"{k}: {v} zile\n")

    ctk.CTkButton(top, text="Calculează", fg_color="#007ACC", height=40, command=calculeaza).pack(pady=10)

# ---------------------------------------------------------
# UI PRINCIPAL
# ---------------------------------------------------------
def run_ui():
    global tip_var, luna_var, an_var

    root = ctk.CTk()
    root.title("Pontaje")
    root.geometry("600x700")

    title = ctk.CTkLabel(
        root,
        text="Generator Pontaje",
        font=ctk.CTkFont(size=24, weight="bold")
    )
    title.pack(pady=15)

    card_select = ctk.CTkFrame(root, corner_radius=15)
    card_select.pack(fill="x", padx=20, pady=10)

    ctk.CTkLabel(card_select, text="Selectare pontaj",
                 font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)

    grid = ctk.CTkFrame(card_select)
    grid.pack(pady=5)

    ctk.CTkLabel(grid, text="Tip:", font=ctk.CTkFont(size=13)).grid(row=0, column=0, padx=10, pady=5, sticky="e")
    tipuri = lista_tipuri_pontaj()
    valoare_initiala = tipuri[0] if tipuri else ""

    tip_var = ctk.StringVar(value=valoare_initiala)

    ctk.CTkComboBox(
    grid,
    values=tipuri,
    variable=tip_var,
    width=180
).grid(row=0, column=1, padx=10, pady=5)


    # lista lunilor cu nume
    luni_nume = [
        "Ianuarie", "Februarie", "Martie", "Aprilie",
        "Mai", "Iunie", "Iulie", "August",
        "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ]

    ctk.CTkLabel(grid, text="Luna:", font=ctk.CTkFont(size=13)).grid(
        row=1, column=0, padx=10, pady=5, sticky="e"
    )

    luna_var = ctk.StringVar(value=luni_nume[datetime.now().month - 1])

    ctk.CTkComboBox(
    grid,
    values=luni_nume,
    variable=luna_var,
    width=180
    ).grid(row=1, column=1, padx=10, pady=5)


    ctk.CTkLabel(grid, text="An:", font=ctk.CTkFont(size=13)).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    an_var = ctk.StringVar(value=str(datetime.now().year))
    ctk.CTkComboBox(grid, values=[str(i) for i in range(2020, 2036)],
                    variable=an_var, width=180).grid(row=2, column=1, padx=10, pady=5)

    card_ops = ctk.CTkFrame(root, corner_radius=15)
    card_ops.pack(fill="x", padx=20, pady=10)

    ctk.CTkLabel(
    card_ops,
    text="Operațiuni",
    font=ctk.CTkFont(size=16, weight="bold")
    ).grid(row=0, column=0, columnspan=3, pady=10)

# Rândul 1
    ctk.CTkButton(
    card_ops, text="Deschide tabel pontaj",
    fg_color="#4CAF50", hover_color="#3E8E41",
    height=40, command=deschide_tabel_pontaj
    ).grid(row=1, column=0, padx=10, pady=5, sticky="ew")

    ctk.CTkButton(
    card_ops, text="Marcaje speciale",
    fg_color="#007ACC", height=40,
    command=fereastra_marcaje_speciale
    ).grid(row=1, column=1, padx=10, pady=5, sticky="ew")

    ctk.CTkButton(
    card_ops, text="Adaugă angajat",
    fg_color="#6A1B9A", height=40,
    command=adauga_angajat
    ).grid(row=1, column=2, padx=10, pady=5, sticky="ew")

# Rândul 2
    ctk.CTkButton(
    card_ops, text="Șterge angajat",
    fg_color="#D32F2F", height=40,
    command=sterge_angajat
).grid(row=2, column=0, padx=10, pady=5, sticky="ew")

    ctk.CTkButton(
    card_ops, text="Modifică angajat",
    fg_color="#0288D1", height=40,
    command=modifica_angajat
    ).grid(row=2, column=1, padx=10, pady=5, sticky="ew")
    
    ctk.CTkButton(
    card_ops, text="Statistici angajat",
    fg_color="#8E24AA", height=40,
    command=statistici_angajat
).grid(row=2, column=2, padx=10, pady=5, sticky="ew")



# Coloană goală pentru simetrie
    card_ops.grid_columnconfigure(0, weight=1)
    card_ops.grid_columnconfigure(1, weight=1)
    card_ops.grid_columnconfigure(2, weight=1)


    card_gen = ctk.CTkFrame(root, corner_radius=15)
    card_gen.pack(fill="x", padx=20, pady=10)

    ctk.CTkLabel(card_gen, text="Generare pontaj",
                 font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)

    ctk.CTkButton(card_gen, text="Generează pontaj",
                  fg_color="#FF9800", height=45,
                  command=genereaza_pontaj).pack(fill="x", padx=20, pady=10)
    
    # ------ COPYRIGHT ------------

    ctk.CTkLabel(
    root,
    text="© Ciucă Denis Software",
    font=ctk.CTkFont(size=12, weight="bold"),
    text_color="#555555"
).pack(pady=10)


    root.mainloop()
